# 🚀 手动发布指南

由于GitHub Actions可能需要额外配置，这里提供手动上传发布包的完整步骤。

## 📦 发布包信息

### 已准备的文件：
- **位置**：`release-package/biliCLI-linux-amd64.tar.gz`
- **大小**：约2.8MB
- **内容**：完整的预编译二进制和脚本

## 🎯 手动上传步骤

### 1. 访问GitHub Release页面
打开：https://github.com/diyiliumin/biliCLI/releases

### 2. 创建新Release
点击 "Draft a new release" 按钮

### 3. 填写Release信息

**标签版本**：`v1.0.0`

**Release标题**：`v1.0.0 - First stable release with no-compile support`

**描述内容**：
```markdown
🎵 biliCLI v1.0.0 正式版发布！

## ✨ 新功能
- 🚀 **一键安装**：提供免编译安装脚本
- 📦 **预编译二进制**：Linux/macOS 64位支持
- 🔧 **自动化发布**：GitHub Actions工作流
- 📖 **完善文档**：详细的安装和使用指南

## 📦 下载说明
- `biliCLI-linux-amd64.tar.gz` - Linux 64位版本
- `biliCLI-darwin-amd64.tar.gz` - macOS 64位版本 (需要构建)

## 🚀 快速安装
```bash
# 一键安装（推荐）
curl -sSL https://raw.githubusercontent.com/diyiliumin/biliCLI/main/install.sh | bash

# 手动安装
wget https://github.com/diyiliumin/biliCLI/releases/download/v1.0.0/biliCLI-linux-amd64.tar.gz
tar -xzf biliCLI-linux-amd64.tar.gz
cd biliCLI-linux-amd64
./launch
```

## ⚠️ 系统要求
- Linux/macOS 64位系统
- ffplay (ffmpeg)
- Python 3.8+
- xxd (通常已预装)

## 🔧 使用说明
1. 编辑 `config.json` 设置音频目录
2. 运行 `./launch` 启动程序
3. 按提示构建索引
4. 使用方向键导航，按 `p` 键播放

## 🐛 已知问题
- Windows用户建议使用WSL
- 首次使用需要手动构建音频索引

感谢使用！🎉
```

### 4. 上传二进制文件
点击 "Attach binaries by dropping them here or selecting them." 区域

选择文件：`release-package/biliCLI-linux-amd64.tar.gz`

### 5. 设置发布选项
- ✅ 设置为预发布（可选，如果是测试版本）
- ✅ 设置为最新版本（推荐）

### 6. 发布Release
点击 "Publish release" 按钮

## ✅ 验证发布

### 检查下载链接
发布后，验证下载链接是否有效：
```bash
# 测试下载链接
wget https://github.com/diyiliumin/biliCLI/releases/download/v1.0.0/biliCLI-linux-amd64.tar.gz

# 检查文件完整性
tar -tzf biliCLI-linux-amd64.tar.gz
```

### 测试一键安装脚本
```bash
# 测试安装脚本
curl -sSL https://raw.githubusercontent.com/diyiliumin/biliCLI/main/install.sh | bash
```

## 🎯 后续版本发布流程

### 对于开发者（你）：
1. 代码开发完成
2. 更新版本号：`git tag -a v1.1.0 -m "Release v1.1.0"`
3. 推送标签：`git push origin v1.1.0`
4. 手动创建Release并上传新的二进制包

### 对于用户：
1. 访问Release页面
2. 下载最新版本
3. 按照README指南安装使用

## 📋 发布清单

- [ ] 代码推送到GitHub
- [ ] 创建Git标签
- [ ] 构建发布包
- [ ] 创建GitHub Release
- [ ] 上传二进制文件
- [ ] 验证下载链接
- [ ] 测试安装脚本
- [ ] 更新文档说明

## 🆘 常见问题

### Q: GitHub Actions失败了怎么办？
A: 使用这个手动发布指南，直接上传预编译的二进制包。

### Q: 发布包应该包含哪些文件？
A: 参考当前结构：所有二进制、脚本、配置文件和文档。

### Q: 如何支持更多平台？
A: 在本地构建对应平台的版本，然后分别上传。

### Q: 用户反馈安装问题怎么办？
A: 引导他们查看README的故障排除部分，或提交Issue。

---

发布完成后，你的用户就可以享受一键安装的便利了！🎉
# 🚀 紧急上传指南

由于API调用限制，这里提供最直接的手动上传方法。

## 🎯 立即行动步骤

### 1. 直接访问GitHub Release页面
打开浏览器，访问：
```
https://github.com/diyiliumin/biliCLI/releases/new
```

### 2. 填写Release信息（复制粘贴）

**标签（Tag）**: `v1.0.0`

**标题**: `v1.0.0 - First stable release with no-compile support`

**描述内容**:
```
🎵 biliCLI v1.0.0 正式版发布！

## ✨ 新功能
- 🚀 **一键安装**：提供免编译安装脚本
- 📦 **预编译二进制**：Linux 64位支持
- 🔧 **自动化发布**：GitHub Actions工作流
- 📖 **完善文档**：详细的安装和使用指南

## 🚀 快速安装

### 方式一：一键安装（推荐）
```bash
curl -sSL https://raw.githubusercontent.com/diyiliumin/biliCLI/main/install.sh | bash
```

### 方式二：手动下载
```bash
# 下载并解压
wget https://github.com/diyiliumin/biliCLI/releases/download/v1.0.0/biliCLI-linux-amd64.tar.gz
tar -xzf biliCLI-linux-amd64.tar.gz
cd biliCLI-linux-amd64

# 编辑配置
nano config.json
# 修改为：{"root": "/你的/音频/目录/路径"}

# 运行！
./launch
```

## 📦 包含内容
- ✅ buildtree: Rust音频扫描器 (855KB)
- ✅ mytui: Go终端界面 (4.6MB)
- ✅ play: 播放控制脚本 (2.9KB)
- ✅ fake_hex: 视觉效果工具 (16KB)
- ✅ launch: 启动器 (16KB)
- ✅ Python辅助脚本 (全套)
- ✅ 完整文档和配置

## ⚠️ 系统要求
- Linux 64位系统 (x86_64)
- ffplay (ffmpeg)
- Python 3.8+
- xxd (通常已预装)

## 🔧 使用说明
1. 编辑 `config.json` 设置音频目录
2. 运行 `./launch` 启动程序
3. 按提示构建索引
4. 使用方向键导航，按 `p` 键播放
5. 播放时按 `p` 暂停，按 `x` 退出

## 📋 文件结构
```
biliCLI-linux-amd64/
├── buildtree/target/release/buildtree  # 音频扫描器
├── cmd/tui/mytui                       # TUI界面
├── play fake_hex launch                # 核心工具
├── 01_*.py 02_*.py 03_*.py 04_*.py    # Python脚本
├── config.json                         # 配置文件
├── install.sh                          # 一键安装脚本
├── README.md                           # 完整文档
└── LICENSE                             # 许可证
```

感谢使用！🎉
```

### 3. 上传二进制文件

**选择文件**：点击 "Attach binaries by dropping them here or selecting them."

**选择这个文件**：
```
/home/ayazumi/AAAworkplace/biliCLI_backup/dist/biliCLI-linux-amd64.tar.gz
```

**文件大小**：约 2.8MB

### 4. 发布设置
- ✅ **Set as the latest release** (设为最新版本)
- ❌ **This is a pre-release** (不是预发布)

### 5. 点击发布
点击绿色按钮：**"Publish release"**

## ✅ 验证步骤

### 立即验证（上传后）：
```bash
# 测试下载链接
wget https://github.com/diyiliumin/biliCLI/releases/download/v1.0.0/biliCLI-linux-amd64.tar.gz

# 检查文件
tar -tzf biliCLI-linux-amd64.tar.gz

# 测试安装脚本
curl -sSL https://raw.githubusercontent.com/diyiliumin/biliCLI/main/install.sh | bash
```

### 预期结果：
- ✅ 下载成功
- ✅ 解压后文件完整
- ✅ 一键安装脚本正常工作

## 🆘 如果上传失败

### 检查文件大小限制：
- GitHub免费用户：每个文件最大2GB
- 我们的文件：2.8MB ✅ 完全没问题

### 检查网络连接：
- 确保能访问GitHub
- 尝试刷新页面
- 清除浏览器缓存

### 替代方案：
1. **分卷上传**：如果文件太大（我们的不需要）
2. **Git LFS**：对于超大文件（我们的不需要）
3. **其他平台**：如Gitee、GitLab（不推荐）

## 📱 手机操作

如果电脑不方便，手机也可以：
1. 手机浏览器访问GitHub Release页面
2. 切换到桌面版网站模式
3. 按照同样步骤上传

## ⏰ 时间预估

整个上传过程约需 **2-5分钟**：
- 填写信息：1分钟
- 上传文件：1-3分钟（取决于网络）
- 验证发布：1分钟

---

**🎯 现在就去上传吧！**

上传完成后，你的用户就可以享受一键安装的便利了！🎉

有问题随时回来查看故障排除部分。